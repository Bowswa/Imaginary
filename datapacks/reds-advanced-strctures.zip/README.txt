
Official link: https://www.planetminecraft.com/member/tmx_red/

English:

Ditributing this datapack is not allowed. If you want to publish
something which contains this datapack you must credit me and provide an easily 
accessible link to the datapacks official website. I would also appreciate it, if
you would send me a message if you used my datapck as part of your own creation.



Discord link: 
https://discord.gg/vYrmuW2h54

