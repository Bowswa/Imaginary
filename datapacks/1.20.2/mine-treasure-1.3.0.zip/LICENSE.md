LICENSE

You may:

Use this data pack on a public multiplayer server provided you credit me in the server's description and leave a link to the Planet Minecraft/Modrinth page.

Record a video series where you use this data pack, but I would appreciate being credited. Leave a link to the Planet Minecraft/Modrinth page. 

Modify this data pack for your own personal use.

You may not:

Upload this data pack to other sites or as part of a larger data pack or modpack unless granted explicit permission from me regardless of modifications.

© 2023 Frozytime. All Rights Reserved.